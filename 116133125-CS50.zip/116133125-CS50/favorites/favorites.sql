select * from shows order by title;
UPDATE shows SET title = "How I Met Your Mother" WHERE title Like "How i met your mother";
update shows set title="Brooklyn Nine-Nine" where title like "%99";
update shows set title="Game of Thrones" where title="GoT";
update shows set title="Grey’s Anatomy" where title like "Grey%";
update shows set title="It’s Always Sunny in Philadelphia" where title like "%Philadephia";
update shows set title="Parks and Recreation" where title like "Parks and Rec";
update shows set title="The Office" where title like "the office";

