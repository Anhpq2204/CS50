create table houses(
    id INTEGER,
    house TEXT,
    head TEXT,
    PRIMARY KEY(id)
);
create table new_students(
    id INTEGER,
    student_name TEXT,
    PRIMARY KEY(id)
);
create table new_students(
    id INTEGER,
    student_name TEXT,
    PRIMARY KEY(id)
);
create table relationship(
    id INTEGER,
    student_name TEXT,
    house TEXT,
    PRIMARY KEY(id)
);
