#include "bmp.h"

// colorize image
void colorize(int height, int width, RGBTRIPLE image[height][width]);

